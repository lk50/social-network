a subdirectory to hold the main figures featured in the paper
