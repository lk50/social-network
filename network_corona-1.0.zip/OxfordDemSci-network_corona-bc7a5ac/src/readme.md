source files to replicate the simulations in the paper
